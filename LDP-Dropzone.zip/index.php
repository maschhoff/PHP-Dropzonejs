<html>
 
<head>   
 

<!-- 1 -->
<link href="./upload/dropzone.css" type="text/css" rel="stylesheet" />
<style>

IMG.displayed {
    display: block;
    margin-left: auto;
    margin-right: auto }

body{font-family: verdana;
font-size: 20px;}
.form{  display: block;
    margin-left: auto;
    margin-right: auto; width: 80%; height: 15em; background-color: #CCCCCC; border: 3px dotted red; }
</style>
<!-- 2 -->
<script src="./upload/dropzone.js"></script>
 
</head>
 
<body>
 
 <IMG class="displayed" src="http://www.little-devil.de/little-devil_logo_klein.jpg" alt="little-devil.de" width="10%">



 
<!-- 3 -->
<form action="./upload/upload.php" class="dropzone" id="demo-upload">


    



</form>

   
</body>
 
</html>